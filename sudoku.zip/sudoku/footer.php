<?php       // PHP CODE FOR INCLUDING FOOTER IN ALL PAGES 	

function print_footer()
{
    print('

			<div id="footer">
				<p> &copy; 2017 Julia Gabajova for <a href="http://www.mdx.ac.uk/">Middlesex University</a></p>

				  <script type="text/javascript" src="js/main.js"></script>
  				  <script type="text/javascript" src="js/login.js"></script>

		    </div> <!--end of footer-->

    ');
}
